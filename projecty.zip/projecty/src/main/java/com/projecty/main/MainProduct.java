package com.projecty.main;

import org.hibernate.Session;

import com.projecty.model.Product;
import com.projecty.util.HibernateUtil;

public class MainProduct {
	
	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Product p = session.load(Product.class, 1);
		System.out.println(p.getName() + " :" + p.getPrice());
		System.out.println("____________________");
		//session / first level cache
		session.getTransaction().commit();
		session.close();
		//----------------------------------------
		session = HibernateUtil.getSession();
		session.beginTransaction();
		p = session.load(Product.class, 1);
		System.out.println(p.getName() + " :" + p.getPrice());
		System.out.println("_______________");
		
		session.getTransaction().commit();
		
		session.close();
		
	}

}
